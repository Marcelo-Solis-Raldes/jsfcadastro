package br.com.jsfcadastro.repository;

import br.com.jsfcadastro.model.PessoaModel;
import br.com.jsfcadastro.util.Conexao;
import br.com.jsfcadastro.util.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marce
 */
public class UsuarioRepository extends Conexao{
    
    public List<PessoaModel> buscar(String login){
        List<PessoaModel> listaDePessoas = new ArrayList<PessoaModel>();
        super.inicializa();
        listaDePessoas = super.getSess().createQuery("from PessoaModel where login = '"+login+"'").list();
        super.executar();
        return listaDePessoas;
    }
    public Usuario buscarPorID(long idPessoa){
        Usuario usu = new Usuario();
        super.inicializa();
        usu = (Usuario) super.getSess().get(Usuario.class, idPessoa);
        super.executar();
        return usu;
    }
}
