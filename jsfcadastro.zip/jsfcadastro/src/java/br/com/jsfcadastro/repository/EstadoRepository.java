package br.com.jsfcadastro.repository;
import br.com.jsfcadastro.model.EstadoModel;
import br.com.jsfcadastro.util.Conexao;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author marce
 */
public class EstadoRepository extends Conexao{
    public List<EstadoModel> buscarTodos(){
        List<EstadoModel> listaDeEstados = new ArrayList<>();
        super.inicializa();
        listaDeEstados = super.getSess().createQuery("from EstadoModel").list();
        super.executar();
        return listaDeEstados;
    }
    
    public EstadoModel buscarPorID(int estadoId){
        EstadoModel estado = new EstadoModel();
        super.inicializa();
        estado = (EstadoModel) super.getSess().get(EstadoModel.class, estadoId);
        super.executar();
        return estado;
    }
}
